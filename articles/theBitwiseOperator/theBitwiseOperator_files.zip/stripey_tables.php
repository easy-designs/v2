<?php
 //SQL connection scripts required.
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
  <title>Get a Speed Boost from the Bitwise Operator</title>
</head>
<body>
<table>
  <thead>
    <tr>
      <th>Event Date</th>
      <th>Event Title</>
    </tr>
  </thead>
  <tbody>
<?php
  // Define colors for the alternating rows
  $color1 = "#CCCCCC";
  $color2 = "#FFFFFF";
  $row_count = 0;
  // SQL query.
  $sql = mysql_query( "SELECT * FROM events" ) or die( mysql_error() );
  while( $row = mysql_fetch_array( $sql ) ){
    $id = $row["id"];
    $date = $row["date"];
    $title = $row["title"];
    
    // Alternate the colors between the two colors we defined above.
    
    //Modulo version
    //$row_color = ( $row_count % 2 ) ? $color1 : $color2;
    
    //Bitwise version
    $row_color = ( ( $row_count & 1 ) == 0 ) ? $color1 : $color2;
    
    // Echo your table row ?>
    <tr>
      <td bgcolor="<?= $row_color ?>"><?= $date ?></td>
      <td bgcolor="<?= $row_color ?>"><a href="articles.php?article_id=<?= $id ?>"><?= $title ?></a></td>
    </tr>
<?php
    // Add 1 to the row count
    $row_count++;
  }
?>
  <tbody>
</table>
</body>
</html>